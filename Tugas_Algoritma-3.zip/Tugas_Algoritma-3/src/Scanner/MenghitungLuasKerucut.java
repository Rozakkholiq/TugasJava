/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;
/**
 *
 * @author MuhammadRozakKholiq
 */
public class MenghitungLuasKerucut {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        double luas, s, r;
        
        System.out.print("Inputkan nilai s =");
        s = Double.valueOf(scan.nextLine());
        
        System.out.print("Inputkan nilai r =");
        r = Double.valueOf(scan.nextLine());
        
        luas = 3.14*r*s+3.14*r;
        System.out.println("Hasil luas kerucut ="+luas);
        
        //r=luas alas
        //s=luas selimut
    }
            
}
