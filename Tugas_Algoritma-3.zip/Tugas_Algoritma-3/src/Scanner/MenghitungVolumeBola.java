package Scanner;

import java.util.Scanner;
/**
 *
 * @author MuhammadRozakKholiq
 */
public class MenghitungVolumeBola {
    public static void main(String[] args){
        Scanner scan =new Scanner(System.in);
        double volume, r;
        
        System.out.print("Nilai r =");
        r = Double.valueOf(scan.nextLine());
        
        volume = 0.4/0.3*3.14*r*r*r;
        System.out.println("Volume bola adalah ="+volume);
        
        //r=jari-jari
        
    }
            
            
}
